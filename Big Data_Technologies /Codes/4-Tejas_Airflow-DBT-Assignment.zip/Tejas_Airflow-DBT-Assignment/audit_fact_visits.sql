with
    stg_tickets as (
        select
            ticket_id,
            customer_id,
            haunted_house_id,
            purchase_date,
            visit_date,
            ticket_type,
            ticket_price

        from {{ ref('stg_haunted_house_tickets') }}
    )

    , stg_feedbacks as (
        select
            ticket_id,
            rating,
            comments

        from {{ ref('stg_customer_feedbacks') }}
    )

    , joined as (
        select
            t.ticket_id,
            t.customer_id,
            t.haunted_house_id,
            t.purchase_date,
            t.visit_date,
            t.ticket_type,
            t.ticket_price,
            cast(f.rating as float) as rating,
            f.comments

        from stg_tickets t
        left join stg_feedbacks f
            on t.ticket_id = f.ticket_id 
    )

select *
from joined
where purchase_date = '2024-11-06'
