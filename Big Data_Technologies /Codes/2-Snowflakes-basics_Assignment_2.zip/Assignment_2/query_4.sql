CREATE SCHEMA IF NOT EXISTS dataexpert_student.rauttejas;

CREATE TABLE IF NOT EXISTS dataexpert_student.rauttejas.nba_games_aggregated (
    season VARCHAR,
    team_id VARCHAR,
    team_abbreviation VARCHAR,
    player_id VARCHAR,
    player_name VARCHAR,
    player_points INTEGER,
    team_points INTEGER,
    team_wins INTEGER
);



SET season = 2022;

MERGE INTO dataexpert_student.rauttejas.nba_games_aggregated target USING  (  

    WITH this_season AS (
      SELECT
        g.season,
        d.game_id,
        d.team_id,
        COALESCE(d.team_abbreviation, 'Ref_teamID') AS team_abbreviation,
        d.player_id,
        CASE 
          WHEN d.player_name = 'T.J. Leaf' THEN 'TJ Leaf'  -- Changed in 2019
          WHEN d.player_name = 'Nic Claxton' THEN 'Nicolas Claxton'  -- Changed in 2020
          WHEN d.player_name = 'Enes Freedom' THEN 'Enes Kanter'  -- Changed in 2021
          WHEN d.player_name = 'O.G. Anunoby' THEN 'OG Anunoby'  -- Changed in 2021
          ELSE d.player_name
        END AS player_name,
        -- COALESCE(d.player_name, 'Ref_playerID') AS player_name,
        d.pts AS player_points,
        CASE 
          WHEN g.home_team_id = d.team_id
            THEN g.pts_home
          WHEN g.visitor_team_id = d.team_id
            THEN g.pts_away
        END AS team_points,
        CASE
          WHEN g.home_team_id = d.team_id 
               AND g.home_team_wins = 1
            THEN 1
          WHEN g.visitor_team_id = d.team_id 
               AND g.home_team_wins = 1
            THEN 0
          WHEN g.home_team_id = d.team_id 
               AND g.home_team_wins = 0
            THEN 0
          WHEN g.visitor_team_id = d.team_id 
               AND g.home_team_wins = 0
            THEN 1
        END AS team_wins
      FROM
        bootcamp.nba_game_details d JOIN bootcamp.nba_games g 
            ON d.game_id = g.game_id
      WHERE
        g.season = $season 
          AND d.game_id IS NOT NULL
          AND d.team_id IS NOT NULL
          AND d.player_id IS NOT NULL
          AND g.season IS NOT NULL
          AND g.home_team_wins IS NOT NULL
      GROUP BY
        1,2,3,4,5,6,7,8,9
    )
    
      SELECT 
        CASE 
          WHEN season IS NULL
              AND player_id IS NOT NULL
              AND team_id IS NOT NULL
            THEN 'For_Player_Team'
          WHEN season IS NULL
              AND player_id IS NULL
              AND team_id IS NOT NULL
            THEN 'For_Team'
          WHEN season IS NOT NULL
            THEN CAST(season AS VARCHAR)
        END AS season,
        CASE 
          WHEN team_id IS NULL
            THEN 'For_Player_Season'
          ELSE CAST(team_id AS VARCHAR)
        END AS team_id,
        CASE 
          WHEN team_abbreviation IS NULL
            THEN 'For_Player_Season'
          ELSE team_abbreviation
        END AS team_abbreviation,
        CASE 
          WHEN player_id IS NULL
            THEN 'For_Team'
          ELSE CAST(player_id AS VARCHAR)
        END AS player_id,
        CASE 
          WHEN player_name IS NULL
            THEN 'For_Team'
          ELSE player_name
        END AS player_name,
        SUM(player_points) AS player_points,
        SUM(team_points) AS team_points,
        SUM(team_wins) AS team_wins
      FROM 
        this_season
      GROUP BY 
        GROUPING SETS (
        (player_id, player_name, team_id, team_abbreviation),
        (player_id, player_name, season),
        (team_id, team_abbreviation)
        )
        
) as v
    ON target.season = v.season 
        AND target.team_id = v.team_id
        AND target.player_id = v.player_id
    
WHEN MATCHED AND NOT EXISTS (SELECT 1 FROM dataexpert_student.rauttejas.nba_games_aggregated WHERE season = CAST($season AS VARCHAR)) THEN 
  UPDATE SET 
    target.player_points = target.player_points + v.player_points,
    target.team_points = target.team_points + v.team_points,
    target.team_wins = target.team_wins + v.team_wins
    
    
    
WHEN NOT MATCHED THEN 
  INSERT (
    season,
    team_id,
    team_abbreviation,
    player_id,
    player_name,
    player_points,
    team_points,
    team_wins 
  )
  VALUES (
    v.season, 
    v.team_id, 
    v.team_abbreviation, 
    v.player_id,
    v.player_name,
    v.player_points,
    v.team_points,
    v.team_wins
  );


-- 4) "Which player scored the most points in one season?"
WITH ranked_player_team AS (
    SELECT 
        *,
        DENSE_RANK() OVER (ORDER BY player_points DESC) AS rnk
    FROM dataexpert_student.rauttejas.nba_games_aggregated
    WHERE team_id = 'For_Player_Season'
)
SELECT player_id, player_name, player_points
FROM ranked_player_team
WHERE rnk = 1;