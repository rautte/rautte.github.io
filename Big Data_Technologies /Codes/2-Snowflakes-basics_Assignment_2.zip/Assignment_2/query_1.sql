CREATE SCHEMA IF NOT EXISTS dataexpert_student.rauttejas;

CREATE TABLE IF NOT EXISTS dataexpert_student.rauttejas.nba_players_state_change (
    player_name VARCHAR,
    is_active BOOLEAN,
    first_active_season INTEGER,
    last_active_season INTEGER,
    active_seasons ARRAY,
    current_season INTEGER,
    player_state VARCHAR
);



SET season = 2022;

MERGE INTO dataexpert_student.rauttejas.nba_players_state_change target USING  (  

    WITH this_season AS (
      SELECT
        player_name,
        True AS is_active,
        ARRAY_CONSTRUCT(season) AS active_seasons,
        season AS current_season
      FROM
        dataexpert_student.bootcamp.nba_player_seasons
      WHERE 
        season = $season
    ),
    last_season AS (
      SELECT *
      FROM dataexpert_student.rauttejas.nba_players_state_change
      WHERE current_season = $season - 1
    )
    
    SELECT 
      COALESCE(n.player_name, p.player_name) AS player_name,
      COALESCE(p.is_active, False) AS is_active,
      COALESCE(n.first_active_season, p.current_season) AS first_active_season,
      COALESCE(p.current_season, n.last_active_season) AS last_active_season,
      CASE
        WHEN n.player_name IS NULL THEN p.active_seasons
        WHEN p.player_name IS NULL THEN n.active_seasons
        ELSE ARRAY_CAT(n.active_seasons, p.active_seasons)
      END AS active_seasons,
      $season AS current_season,
      CASE
        WHEN n.is_active IS NULL AND p.is_active = True
          THEN 'New'
        WHEN n.is_active = False AND p.is_active = True
          THEN 'Returned from Retirement'
        WHEN n.is_active = True AND p.is_active = True
          THEN 'Continued Playing'
        WHEN n.is_active = False AND p.is_active IS NULL 
          THEN 'Stayed Retired'
        WHEN n.is_active = True AND p.is_active IS NULL
          THEN 'Retired'
      END AS player_state
    FROM 
      last_season n FULL OUTER JOIN this_season p
        ON n.player_name = p.player_name 
        
    ) as v
    ON target.player_name = v.player_name AND target.current_season = v.current_season
    
WHEN MATCHED THEN 
  UPDATE SET 
    target.player_name = v.player_name,
    target.is_active = v.is_active,
    target.first_active_season = v.first_active_season,
    target.last_active_season = v.last_active_season,
    target.active_seasons = v.active_seasons,
    target.current_season = v.current_season,
    target.player_state = v.player_state
    
WHEN NOT MATCHED THEN 
  INSERT (
    player_name, 
    is_active, 
    first_active_season, 
    last_active_season, 
    active_seasons, 
    current_season, 
    player_state
  )
  VALUES (
    v.player_name, 
    v.is_active, 
    v.first_active_season, 
    v.last_active_season, 
    v.active_seasons, 
    v.current_season, 
    v.player_state
  );


